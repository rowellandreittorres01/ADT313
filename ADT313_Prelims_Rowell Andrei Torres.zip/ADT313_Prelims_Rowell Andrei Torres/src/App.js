import logo from './logo.svg';
import './App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Instructions from './Exams/Instruction';
import Problem1 from './Exams/Problem1Component/Problem1';
import Problem2 from './Exams/Problem2ConditionalRendering/Problem2';
import Problem3 from './Exams/Problem3UseRef/Problem3';
import Problem4 from './Exams/Problem4UseState/Problem4';
import Problem5 from './Exams/Problem5UseEffect/Problem5';
import Problem6 from './Exams/Problem6UseCallback/Problem6';
import Problem7 from './Exams/Problem7UseContext/Problem7';
import Problem8 from './Exams/Problem8UseReducer/Problem8';
import StudentDetails from './Exams/Problem1Component/Problem1';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Instructions />,
  },
  {
    path: '/problem1',
    element: (
      <div>
        <h1>Problem 1 - Component (10pts)</h1>
        <StudentDetails
          studentName="Rowell Andrei T. Torres"
          course="BSIT"
          section="A"
        />
      </div>
    ),
  },
  {
    path: '/problem2',
    element: (
      <div>
        <h1>Problem 2: Conditional Rendering (10pts)</h1>
        <Problem2 />
      </div>
    ),
  },
  {
    path: '/problem3',
    element: (
      <div>
        <h1>Problem 3: useRef (10pts)</h1>
        <Problem3 />
      </div>
    ),
  },
  {
    path: '/problem4',
    element: (
      <div>
        <h1>Problem 4: useState (10pts)</h1>
        <Problem4 />
      </div>
    ),
  },
  {
    path: '/problem5',
    element: (
      <div style={{ height: '100%' }}>
        <h1>Problem 5: useEffect (20pts)</h1>
        <Problem5 />
      </div>
    ),
  },
  {
    path: '/problem6',
    element: (
      <div style={{ height: '100%' }}>
        <h1>Problem 6: useCallback (50pts)</h1>
        <Problem6 />
      </div>
    ),
  },
  {
    path: '/problem7',
    element: (
      <div style={{ height: '100%' }}>
        <h1>Problem 7: useContext (40pts)</h1>
        <Problem7 />
      </div>
    ),
  },
  {
    path: '/problem8',
    element: (
      <div style={{ height: '100%' }}>
        <h1>Problem 8: useReducer (50pts)</h1>
        <Problem8 />
      </div>
    ),
  },
]);

function App() {
  return (
    <div className="App">
      <h1>ADT313 Prelims Retake & Special Exam</h1>
      <ol className="navigation" start="0">
        <li>
          <a href="/">Instructions</a>
        </li>
        <li>
          <a href="/problem1">Problem 1 - Component (10Pts)</a>
        </li>
        <li>
          <a href="/problem2">Problem 2 - Conditional Rendering (10Pts)</a>
        </li>
        <li>
          <a href="/problem3">Problem 3 - UseRef (10Pts)</a>
        </li>
        <li>
          <a href="/problem4">Problem 4 - UseState(10Pts)</a>
        </li>
        <li>
          <a href="/problem5">Problem 5 - useEffect(20Pts)</a>
        </li>
        <li>
          <a href="/problem6">Problem 6 - UseCallback(50Pts)</a>
        </li>
        <li>
          <a href="/problem7">Problem 7 - useContext(40Pts)</a>
        </li>
        <li>
          <a href="/problem8">Problem 8 - UseReducer(50Pts)</a>
        </li>
      </ol>
      <RouterProvider router={router} />
    </div>
  );
}

export default App;