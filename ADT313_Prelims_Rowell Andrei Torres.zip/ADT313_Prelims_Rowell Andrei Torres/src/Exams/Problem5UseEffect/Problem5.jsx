import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {

  const [isLoading, setIsLoading] = useState(true);
  const [isUserTyping, setIsUserTyping] = useState(false);

  
  const inputRef = useRef(null);

 
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer); 
  }, []);

 
  const handleUserTyping = () => {
    setIsUserTyping(true);
  };


  const handleUserIdle = () => {
    setIsUserTyping(false);
  };


  useEffect(() => {
    const inputElement = inputRef.current;


    if (inputElement) {
      inputElement.addEventListener('keydown', handleUserTyping);
      inputElement.addEventListener('blur', handleUserIdle);
    }

   
    return () => {
      if (inputElement) {
        inputElement.removeEventListener('keydown', handleUserTyping);
        inputElement.removeEventListener('blur', handleUserIdle);
      }
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type='text' ref={inputRef} />
          <p>{isUserTyping ? 'User is typing...' : 'User is idle...'}</p>
        </div>
      )}
    </>
  );
}
