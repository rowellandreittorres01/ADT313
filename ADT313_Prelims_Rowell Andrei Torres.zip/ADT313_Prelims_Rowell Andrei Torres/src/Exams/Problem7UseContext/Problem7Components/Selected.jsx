import { useDataContext } from '../Problem7';

export default function SelectedValue() {
  const { selectedData } = useDataContext();

  return (
    <div>
      <h3>Selected Item</h3>
      {Object.keys(selectedData).length > 0 ? (
        <table style={{ width: '100%', textAlign: 'left' }}>
          <tbody>
            <tr>
              <td>VIN:</td>
              <td>{selectedData.vin}</td>
            </tr>
            <tr>
              <td>Make:</td>
              <td>{selectedData.make}</td>
            </tr>
            <tr>
              <td>Model:</td>
              <td>{selectedData.model}</td>
            </tr>
            <tr>
              <td>Year:</td>
              <td>{selectedData.year}</td>
            </tr>
            <tr>
              <td>Color:</td>
              <td>{selectedData.color}</td>
            </tr>
          </tbody>
        </table>
      ) : (
        <p>No item selected</p>
      )}
    </div>
  );
}
