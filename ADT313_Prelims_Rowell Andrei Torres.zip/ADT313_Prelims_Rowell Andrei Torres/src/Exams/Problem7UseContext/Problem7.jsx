import { useState, createContext, useContext } from 'react';
import Lists from './Problem7Components/Lists';
import SelectedValue from './Problem7Components/Selected';
import data from './problem7_mock_data.json';


const DataContext = createContext();

export function useDataContext() {
  return useContext(DataContext);
}

export default function Problem7() {
  const [selectedData, setSelectedData] = useState({});
  const [cars, setCars] = useState(data);

  return (
    <DataContext.Provider value={{ cars, selectedData, setSelectedData }}>
      <div>
        <p>Apply UseContext here</p>

        {}
        <div style={{ display: 'block', marginBottom: '20px' }}>
          <SelectedValue />
        </div>

        {}
        <div style={{ display: 'block' }}>
          <Lists />
        </div>
      </div>
    </DataContext.Provider>
  );
}
