import React, { useState } from "react";
import "./App.css";

function App() {
  // State for login
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [name, setName] = useState("");
  const [section, setSection] = useState("");
  const [loginName, setLoginName] = useState("");
  const [loginSection, setLoginSection] = useState("");

  // State for calculator
  const [operation, setOperation] = useState("");

  // Login handler
  const handleLogin = (e) => {
    e.preventDefault();
    setName(loginName);
    setSection(loginSection);
    setIsLoggedIn(true);
  };

  // Operation handler
  const handleOperation = (operation) => {
    let symbol = "";
    switch (operation) {
      case "addition":
        symbol = "+";
        break;
      case "subtraction":
        symbol = "-";
        break;
      case "multiplication":
        symbol = "*";
        break;
      case "division":
        symbol = "/";
        break;
      default:
        symbol = "";
    }
    setOperation(symbol);
    alert(`You chose ${operation} operation.`);
  };

  return (
    <div className="App">
      {!isLoggedIn ? (
        <form onSubmit={handleLogin} className="login-form">
          <h2>Login</h2>
          <div>
            <label>
              Name:{" "}
              <input
                type="text"
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                required
              />
            </label>
          </div>
          <div>
            <label>
              Section:{" "}
              <input
                type="text"
                value={loginSection}
                onChange={(e) => setLoginSection(e.target.value)}
                required
              />
            </label>
          </div>
          <button type="submit">Login</button>
        </form>
      ) : (
        <div>
          <h2>Welcome, {name}!</h2>
          <h3>Section: {section}</h3>
          <h4>Selected Operation: {operation}</h4>

          <div className="calculator">
            <h2>Simple Calculator</h2>
            <button onClick={() => handleOperation("addition")}>Addition</button>
            <button onClick={() => handleOperation("subtraction")}>Subtraction</button>
            <button onClick={() => handleOperation("multiplication")}>
              Multiplication
            </button>
            <button onClick={() => handleOperation("division")}>Division</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
